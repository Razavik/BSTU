function Footer() {
	return (
		<footer>
			<p>© 2024 Media Catalog. Все права защищены.</p>
		</footer>
	);
}

export default Footer;
