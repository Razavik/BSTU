export interface Media {
	img: string;
	title: string;
	year: number;
	category: string;
}
