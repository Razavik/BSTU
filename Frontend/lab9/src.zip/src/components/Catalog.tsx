import Card from "./Card";
import style from "../data/modules/catalog.module.css";

interface Media {
	img: string;
	title: string;
	year: number;
	category: string;
}

interface MediaCatalog {
	path: string;
	info: Media[];
}

interface Props {
	media: MediaCatalog;
}

function Catalog({ media }: Props) {
	return (
		<div className={style.catalog}>
			{media.info.map((value, index) => (
				<Card key={index} path={media.path} {...value} />
			))}
		</div>
	);
}

export default Catalog;
